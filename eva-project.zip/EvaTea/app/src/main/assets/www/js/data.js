/* ===== 菜单数据 ===== */
const CATS = [
  { id: 'hot',    n: '人气爆款', jp: 'HOT' },
  { id: 'cheese', n: '芝士奶盖', jp: 'CHEESE' },
  { id: 'fruit',  n: '鲜果茶',   jp: 'FRUIT' },
  { id: 'milk',   n: '醇香奶茶', jp: 'MILK TEA' },
  { id: 'coffee', n: '咖啡',     jp: 'COFFEE' },
  { id: 'snack',  n: '烘焙小食', jp: 'BAKERY' },
];

const SIZES = [{ n: '中杯', p: 0 }, { n: '大杯', p: 3 }];
const TEMPS_COLD = ['少冰', '去冰', '正常冰'];
const TEMPS_ALL = ['少冰', '去冰', '正常冰', '常温', '热'];
const SUGARS = ['全糖', '七分糖', '五分糖', '三分糖', '无糖'];

const TOPS = {
  pearl:   { n: '黑糖波波', p: 2 },
  coco:    { n: '椰果',     p: 2 },
  pudding: { n: '焦糖布丁', p: 3 },
  taro:    { n: '芋圆',     p: 3 },
  crispy:  { n: '脆啵啵',   p: 3 },
  cheese:  { n: '芝士奶盖', p: 4 },
  redbean: { n: '蜜红豆',   p: 2 },
  jelly:   { n: '茉莉茶冻', p: 2 },
  sago:    { n: '西米',     p: 2 },
  shot:    { n: '浓缩加一份', p: 3 },
};

/* cup: 杯子插画参数(见 cup.js)  hot: 是否出现在"人气爆款" */
const PRODUCTS = [
  { id: 'p1', cat: 'cheese', hot: 1, tag: '新品', name: '红色惊雷·草莓芝士', jp: 'RED THUNDER', price: 19, orig: 22,
    desc: '当季草莓现打果泥，顶上盖一层咸香芝士奶盖，像明日香一样，又甜又倔。',
    cup: { t: 'tn-d1', l: 'tn-d3', top: 'cream', g: 'berry', n: '02' }, temps: TEMPS_COLD, tops: ['pearl', 'coco', 'jelly'], defSugar: 2 },
  { id: 'p2', cat: 'fruit', hot: 1, tag: '招牌', name: '02号机·杨枝甘露', jp: 'UNIT-02', price: 18,
    desc: '厚芒果肉 × 西柚粒 × 椰浆，一口下去整个人同步率飙升。',
    cup: { t: 'tn-d1', top: 'mango', n: '02' }, temps: TEMPS_COLD, tops: ['sago', 'coco', 'pudding'], defSugar: 1 },
  { id: 'p3', cat: 'milk', hot: 1, tag: '热销', name: '惣流·黑糖波波鲜奶', jp: 'SORYU', price: 17,
    desc: '手熬黑糖波波配每日鲜奶，杯壁挂糖纹，咬到嚼劲十足。',
    cup: { t: 'tn-d1', top: 'streak', pearl: 1, n: '03' }, temps: TEMPS_ALL, tops: ['cheese', 'pudding', 'redbean'], defSugar: 1 },
  { id: 'p4', cat: 'milk', hot: 1, tag: '热销', name: '傲娇·茉莉奶绿', jp: 'TSUNDERE', price: 14,
    desc: '茉莉绿茶底，花香清冷，入口却是软糯奶香——嘴硬心软。',
    cup: { t: 'tn-h1', top: 'ice', n: '04' }, temps: TEMPS_ALL, tops: ['pearl', 'coco', 'jelly', 'crispy'], defSugar: 2 },

  { id: 'p14', cat: 'cheese', name: '芝士奶盖红茶', jp: 'CHEESE BLACK', price: 17,
    desc: '锡兰红茶底，盖满绵密咸芝士，建议不吸管，直接喝。',
    cup: { t: 'tn-d2', top: 'cream', n: '05' }, temps: TEMPS_COLD, tops: ['pearl', 'coco'], defSugar: 2 },
  { id: 'p15', cat: 'cheese', name: '芝士奶盖乌龙', jp: 'CHEESE OOLONG', price: 18,
    desc: '炭焙乌龙茶香浓郁，奶盖里撒了可可粉，回味很长。',
    cup: { t: 'tn-h1', top: 'cream', n: '06' }, temps: TEMPS_COLD, tops: ['pearl', 'pudding'], defSugar: 2 },
  { id: 'p16', cat: 'cheese', name: '芝士抹茶牛乳', jp: 'MATCHA CHEESE', price: 19,
    desc: '宇治抹茶搭配鲜牛乳，顶层是抹茶芝士，微苦回甘。',
    cup: { t: 'tn-h2', top: 'cream', n: '07' }, temps: TEMPS_COLD, tops: ['redbean', 'pearl'], defSugar: 2 },

  { id: 'p5', cat: 'fruit', name: '红色警报·西柚茉莉', jp: 'RED ALERT', price: 16,
    desc: '红心西柚手剥果肉，配茉莉绿茶，酸甜在线，清爽到有点危险。',
    cup: { t: 'tn-d2', top: 'ice', g: 'lemon', n: '08' }, temps: TEMPS_COLD, tops: ['coco', 'jelly', 'sago'], defSugar: 2 },
  { id: 'p6', cat: 'fruit', name: 'AT力场·青提气泡', jp: 'AT FIELD', price: 15,
    desc: '青提果肉加气泡水，咕嘟咕嘟冒泡，层层防护般清透。',
    cup: { t: 'tn-h2', top: 'ice', g: 'mint', n: '09' }, temps: ['少冰', '去冰'], tops: ['coco', 'jelly'], defSugar: 2 },
  { id: 'p7', cat: 'fruit', name: '暴走·满杯橙', jp: 'BERSERK', price: 15,
    desc: '一整颗鲜橙现压，加冰块猛灌，维 C 暴走模式。',
    cup: { t: 'tn-d3', top: 'ice', g: 'lemon', n: '10' }, temps: TEMPS_COLD, tops: ['coco', 'sago'], defSugar: 3 },
  { id: 'p8', cat: 'fruit', name: '蜜桃乌龙', jp: 'PEACH OOLONG', price: 16,
    desc: '白桃果肉与冷泡乌龙的组合，桃香甜，茶底清。',
    cup: { t: 'tn-d1', top: 'ice', g: 'berry', n: '11' }, temps: TEMPS_COLD, tops: ['coco', 'jelly'], defSugar: 2 },

  { id: 'p9', cat: 'milk', name: '经典奶茶', jp: 'CLASSIC', price: 12,
    desc: '最朴素的那一杯，红茶与牛乳的黄金比例。',
    cup: { t: 'tn-d1', top: 'ice', pearl: 1, n: '12' }, temps: TEMPS_ALL, tops: ['pearl', 'coco', 'pudding', 'redbean', 'crispy'], defSugar: 1 },
  { id: 'p10', cat: 'milk', name: '乌龙奶茶', jp: 'OOLONG MILK', price: 14,
    desc: '焙火乌龙与奶香平衡，茶感足，不腻。',
    cup: { t: 'tn-h1', top: 'ice', n: '13' }, temps: TEMPS_ALL, tops: ['pearl', 'coco', 'pudding'], defSugar: 2 },
  { id: 'p11', cat: 'milk', name: '抹茶奶茶', jp: 'MATCHA MILK', price: 16,
    desc: '宇治抹茶粉现点现冲，微苦回甘，奶香柔和。',
    cup: { t: 'tn-h2', top: 'ice', n: '14' }, temps: TEMPS_ALL, tops: ['redbean', 'pearl', 'taro'], defSugar: 2 },
  { id: 'p12', cat: 'milk', name: '芋泥波波奶茶', jp: 'TARO BOBA', price: 17,
    desc: '手捣芋泥加波波，杯底沉淀一口扎实的香糯。',
    cup: { t: 'tn-d2', l: 'tn-d3', top: 'ice', pearl: 1, n: '15' }, temps: TEMPS_ALL, tops: ['taro', 'cheese'], defSugar: 1 },
  { id: 'p13', cat: 'milk', name: '阿萨姆奶茶', jp: 'ASSAM', price: 13,
    desc: '阿萨姆红茶浓萃，茶味厚，奶味稳。',
    cup: { t: 'tn-d2', top: 'ice', n: '16' }, temps: TEMPS_ALL, tops: ['pearl', 'coco', 'pudding'], defSugar: 2 },

  { id: 'p17', cat: 'coffee', name: '生椰拿铁', jp: 'COCO LATTE', price: 16,
    desc: '厚椰乳 × 意式浓缩，椰香盖住了苦，清爽不腻。',
    cup: { t: 'tn-d1', l: 'tn-d3', top: 'ice', n: '17' }, temps: TEMPS_ALL, tops: ['shot'], defSugar: 3, noTops: 0 },
  { id: 'p18', cat: 'coffee', name: '冰美式', jp: 'AMERICANO', price: 10,
    desc: '深烘拼配豆，口感干净，提神专用。',
    cup: { t: 'tn-d3', top: 'ice', n: '18' }, temps: TEMPS_ALL, tops: ['shot'], defSugar: 4 },
  { id: 'p19', cat: 'coffee', name: '丝绒拿铁', jp: 'LATTE', price: 14,
    desc: '每日鲜奶打出绵密奶泡，咖啡香浓而柔。',
    cup: { t: 'tn-d1', l: 'tn-d3', top: 'ice', n: '19' }, temps: TEMPS_ALL, tops: ['shot'], defSugar: 3 },
  { id: 'p20', cat: 'coffee', name: '燕麦拿铁', jp: 'OAT LATTE', price: 17,
    desc: '换成燕麦奶，谷物香更足，乳糖不耐也能喝。',
    cup: { t: 'tn-d1', l: 'tn-d2', top: 'ice', n: '20' }, temps: TEMPS_ALL, tops: ['shot'], defSugar: 3 },

  { id: 's1', cat: 'snack', simple: 1, tag: '热销', name: '葡式蛋挞', jp: 'EGG TART', price: 8,
    desc: '千层酥皮，焦糖表面，蛋香浓郁。', snack: 'tart' },
  { id: 's2', cat: 'snack', simple: 1, name: '厚切芝士蛋糕', jp: 'CHEESE CAKE', price: 14,
    desc: '浓厚轻乳酪，饼干底，一口一层。', snack: 'cake' },
  { id: 's3', cat: 'snack', simple: 1, name: '黄油曲奇', jp: 'COOKIE', price: 6,
    desc: '手工黄油曲奇，酥脆掉渣，配奶茶最搭。', snack: 'cookie' },
];

const STORES = [
  { n: 'NERV 总部店',     addr: '第三新东京市 · 特务机关本部 B1', dist: '320m', time: '09:00-22:00' },
  { n: '第三新东京站店',  addr: '第三新东京市 · 轻轨站 2 号出口', dist: '1.2km', time: '08:30-22:30' },
  { n: '箱根芦之湖店',    addr: '箱根芦之湖畔 · 观景台旁',       dist: '3.6km', time: '10:00-21:00' },
];

const BANNERS = [
  { img: 'img/poster.jpg',     pos: '50% 32%', t: '"The world is not kind."',  s: '但这杯，对你很温柔。', go: 'p3' },
  { img: 'img/asuka-red.jpg',  pos: '50% 20%', t: '红色惊雷·草莓芝士',         s: '新品上市 · 限时 ¥19',   go: 'p1' },
  { img: 'img/asuka-cafe.jpg', pos: '50% 38%', t: '2026 EVA 茶研所',           s: '点单自取，免排队',      go: 'menu' },
];
