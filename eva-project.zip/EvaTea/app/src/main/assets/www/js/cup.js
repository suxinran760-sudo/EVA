/* ===== 漫画风杯子插画（纯 SVG，黑白网点 + 一点点红） ===== */
let _cid = 0;
const INK = '#111', RED = '#d4202c';

function cup(o) {
  const id = 'cp' + (++_cid);
  const t = o.t || 'tn-d1';
  const top = o.top || 'none';
  const lt = top === 'cream' ? 68 : 56;           // 液面
  const body = 'M26 44 L94 44 L86 138 Q85.5 144 79 144 L41 144 Q34.5 144 34 138 Z';
  let s = '';

  // 液体
  s += `<rect x="20" y="${lt}" width="80" height="100" fill="#fff"/>`;
  s += `<rect x="20" y="${lt}" width="80" height="100" fill="url(#${t})"/>`;
  if (o.l) {
    const y = lt + 38;
    s += `<path d="M20 ${y} Q40 ${y - 8} 60 ${y} T100 ${y} V150 H20Z" fill="#fff"/>`;
    s += `<path d="M20 ${y} Q40 ${y - 8} 60 ${y} T100 ${y} V150 H20Z" fill="url(#${o.l})"/>`;
  }
  // 奶盖
  if (top === 'cream') {
    s += `<path d="M20 48 H100 V68 Q90 77 80 68 T60 68 T40 68 T20 68Z" fill="#fff"/>`;
    s += `<path d="M20 68 Q30 77 40 68 T60 68 T80 68 T100 68" fill="none" stroke="${INK}" stroke-width="2"/>`;
    [[36,58],[46,63],[58,56],[70,62],[80,57],[52,52],[88,64]].forEach(p => s += `<circle cx="${p[0]}" cy="${p[1]}" r="1.1" fill="${INK}"/>`);
  }
  // 冰块
  if (top === 'ice') {
    [[38,62,-12],[62,60,10],[78,76,-6],[46,88,14]].forEach(p => {
      s += `<g transform="translate(${p[0]} ${p[1]}) rotate(${p[2]})"><rect x="-9" y="-9" width="18" height="18" rx="3" fill="#fff" stroke="${INK}" stroke-width="1.8"/><path d="M-5 -3 L-5 3 M-2 -6 L3 -6" stroke="${INK}" stroke-width="1.4" stroke-linecap="round" fill="none"/></g>`;
    });
  }
  // 芒果粒 / 西米
  if (top === 'mango') {
    [[40,70,8],[58,64,-10],[74,74,12],[48,92,-6],[68,100,6],[56,118,10]].forEach(p => {
      s += `<g transform="translate(${p[0]} ${p[1]}) rotate(${p[2]})"><rect x="-7" y="-7" width="14" height="14" rx="2" fill="#fff" stroke="${INK}" stroke-width="1.8"/><rect x="-7" y="-7" width="14" height="14" rx="2" fill="url(#tn-h1)"/></g>`;
    });
    for (let i = 0; i < 16; i++) s += `<circle cx="${38 + (i * 37 % 44)}" cy="${112 + (i * 17 % 26)}" r="2.2" fill="#fff" stroke="${INK}" stroke-width="1"/>`;
  }
  // 黑糖挂壁
  if (top === 'streak') {
    s += `<path d="M31 52 C38 74 29 96 37 128" fill="none" stroke="${INK}" stroke-width="4" stroke-linecap="round"/>`;
    s += `<path d="M44 58 C48 76 42 90 47 106" fill="none" stroke="${INK}" stroke-width="3" stroke-linecap="round"/>`;
    s += `<path d="M92 58 C88 78 94 96 86 128" fill="none" stroke="${INK}" stroke-width="3.5" stroke-linecap="round"/>`;
    s += `<path d="M72 60 C70 74 75 82 72 94" fill="none" stroke="${INK}" stroke-width="2.5" stroke-linecap="round"/>`;
  }
  // 波波/珍珠
  if (o.pearl) {
    [[42,132],[54,134],[66,133],[78,131],[48,121],[60,122],[72,120],[54,110],[66,109]].forEach(p => {
      s += `<circle cx="${p[0]}" cy="${p[1]}" r="5.2" fill="${INK}"/><circle cx="${p[0] - 1.6}" cy="${p[1] - 1.6}" r="1.3" fill="#fff"/>`;
    });
  }
  // 暗部排线 + 高光
  s += `<rect x="78" y="44" width="24" height="104" fill="url(#tn-h1)" opacity=".85"/>`;
  s += `<path d="M39 54 L43 130" stroke="#fff" stroke-width="3.2" stroke-linecap="round" opacity=".95"/>`;
  s += `<path d="M46 54 L48 80" stroke="#fff" stroke-width="1.6" stroke-linecap="round" opacity=".9"/>`;

  let svg = `<svg class="cup" viewBox="0 0 120 150" xmlns="http://www.w3.org/2000/svg"><defs><clipPath id="${id}"><path d="${body}"/></clipPath></defs>`;
  // 吸管（杯后）
  svg += `<line x1="64" y1="30" x2="79" y2="4" stroke="${INK}" stroke-width="6.5" stroke-linecap="round"/><line x1="64" y1="30" x2="79" y2="4" stroke="#fff" stroke-width="3" stroke-linecap="round"/>`;
  svg += `<g clip-path="url(#${id})">${s}</g>`;
  svg += `<path d="${body}" fill="none" stroke="${INK}" stroke-width="3.2" stroke-linejoin="round"/>`;
  // 杯套（EVA 编号）
  svg += `<path d="M28.9 80 L91.1 80 L88.4 112 L31.6 112 Z" fill="#f4f2ee" stroke="${INK}" stroke-width="2.2"/>`;
  svg += `<text x="60" y="91" text-anchor="middle" font-size="7.5" font-weight="800" letter-spacing="2" fill="${INK}" font-family="Arial,sans-serif">NERV</text>`;
  svg += `<text x="60" y="107" text-anchor="middle" font-size="15" font-weight="900" fill="${RED}" font-family="Arial,sans-serif">${o.n || '02'}</text>`;
  // 杯盖
  svg += `<path d="M29 43 Q31 24 60 23 Q89 24 91 43" fill="#fff" stroke="${INK}" stroke-width="2.6"/>`;
  svg += `<path d="M38 36 Q42 29 52 27" fill="none" stroke="${INK}" stroke-width="1.6" stroke-linecap="round"/>`;
  svg += `<rect x="21" y="41" width="78" height="9" rx="3.5" fill="#fff" stroke="${INK}" stroke-width="3"/>`;
  // 点缀
  if (o.g === 'lemon') {
    svg += `<g transform="translate(97 48)"><circle r="13" fill="#fff" stroke="${INK}" stroke-width="2.6"/><circle r="9" fill="url(#tn-d2)"/>` +
      [0,45,90,135].map(a => `<line x1="0" y1="-9" x2="0" y2="9" stroke="${INK}" stroke-width="1.4" transform="rotate(${a})"/>`).join('') + `</g>`;
  } else if (o.g === 'berry') {
    svg += `<g transform="translate(99 40)"><path d="M0 -2 C11 -6 13 8 0 20 C-13 8 -11 -6 0 -2Z" fill="#fff" stroke="${INK}" stroke-width="2.4"/><path d="M0 -2 C11 -6 13 8 0 20 C-13 8 -11 -6 0 -2Z" fill="url(#tn-d3)"/>` +
      `<path d="M-6 -4 L0 -10 L6 -4 L0 -1Z" fill="${INK}"/>` +
      [[-3,6],[3,8],[0,13],[-4,12],[4,3]].map(p => `<circle cx="${p[0]}" cy="${p[1]}" r=".9" fill="#fff"/>`).join('') + `</g>`;
  } else if (o.g === 'mint') {
    svg += `<path d="M95 44 Q100 28 112 30 Q110 42 95 44Z" fill="#fff" stroke="${INK}" stroke-width="2"/><path d="M95 44 Q96 32 108 31" fill="none" stroke="${INK}" stroke-width="1.2"/>` +
      `<path d="M95 44 Q86 32 76 36 Q80 46 95 44Z" fill="url(#tn-d2)" stroke="${INK}" stroke-width="2"/>`;
  }
  svg += `</svg>`;
  return svg;
}

/* 小食插画 */
function snackSVG(kind) {
  let b = '';
  if (kind === 'tart') {
    b = `<path d="M24 92 L96 92 L88 128 Q87 134 80 134 L40 134 Q33 134 32 128 Z" fill="#fff" stroke="${INK}" stroke-width="3.2" stroke-linejoin="round"/>` +
      `<path d="M30 112 H90 M34 122 H86" stroke="${INK}" stroke-width="1.4"/>` +
      `<path d="M24 92 Q22 62 60 58 Q98 62 96 92 Z" fill="#fff" stroke="${INK}" stroke-width="3.2"/>` +
      `<path d="M24 92 Q22 62 60 58 Q98 62 96 92 Z" fill="url(#tn-d2)"/>` +
      `<circle cx="48" cy="76" r="6" fill="${INK}" opacity=".9"/><circle cx="72" cy="80" r="5" fill="${INK}" opacity=".9"/>` +
      `<path d="M36 70 Q40 64 50 62" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/>`;
  } else if (kind === 'cake') {
    b = `<path d="M18 120 L102 120 L102 96 L34 54 L18 96Z" fill="#fff" stroke="${INK}" stroke-width="3.2" stroke-linejoin="round"/>` +
      `<path d="M18 96 L102 96" stroke="${INK}" stroke-width="2.4"/><path d="M34 54 L102 96" stroke="${INK}" stroke-width="2.4"/>` +
      `<path d="M18 96 L34 54 L102 96Z" fill="url(#tn-d1)"/><rect x="18" y="108" width="84" height="12" fill="url(#tn-d3)"/>` +
      `<path d="M26 104 H96" stroke="#fff" stroke-width="2"/>` +
      `<circle cx="70" cy="80" r="7" fill="#fff" stroke="${INK}" stroke-width="2.4"/><path d="M70 73 Q73 66 78 66" fill="none" stroke="${INK}" stroke-width="2"/>`;
  } else {
    b = `<circle cx="60" cy="90" r="38" fill="#fff" stroke="${INK}" stroke-width="3.2"/><circle cx="60" cy="90" r="38" fill="url(#tn-d1)"/>` +
      [[44,76],[68,70],[76,96],[52,104],[62,88],[40,96]].map(p => `<circle cx="${p[0]}" cy="${p[1]}" r="4.4" fill="${INK}"/>`).join('') +
      `<path d="M36 68 Q42 56 54 54" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>`;
  }
  return `<svg class="cup" viewBox="0 0 120 150" xmlns="http://www.w3.org/2000/svg">${b}</svg>`;
}

function visual(p) { return p.simple ? snackSVG(p.snack) : cup(p.cup); }
